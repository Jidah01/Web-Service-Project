package com.cal;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.xml.ws.WebServiceRef;

@WebServlet(name = "Client", urlPatterns = {"/Client"})
public class Client extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/HealthService/HealthService.wsdl")
    private com.health.HealthService_Service service;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                float weight = Float.parseFloat(request.getParameter("weight"));
                float intake = Float.parseFloat(request.getParameter("intake"));

                com.health.HealthService port = service.getHealthServicePort();
                String result = port.getWaterIntakeStatus(weight, intake);

                out.println("<html><body>");
                out.println("<h2>Water Intake Result</h2>");
                out.println("<p>Status: <strong>" + result + "</strong></p>");
                out.println("<a href='http://localhost:8080/HealthServiceClient/'>Try Again</a>");
                out.println("</body></html>");

            } catch (Exception e) {
                out.println("<html><body>");
                out.println("<h2>Error</h2>");
                out.println("<p style='color:red;'>" + e.getMessage() + "</p>");
                out.println("<a href='index.jsp'>Try Again</a>");
                out.println("</body></html>");
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        response.sendRedirect("index.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Client servlet that communicates with the HealthService SOAP web service";
    }
}

