package com.health;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "HealthService")
public class HealthService {

    @WebMethod(operationName = "getWaterIntakeStatus")
    public String getWaterIntakeStatus(@WebParam(name = "weight") float weight,
                                       @WebParam(name = "intake") float intake) {

        float recommended = weight * 0.033f;
        float hydration = (intake / recommended) * 100;

        if (hydration < 100) {
            return "Bad (" + String.format("%.2f", hydration) + "% hydrated)";
        } else if (hydration == 100) {
            return "Normal (" + String.format("%.2f", hydration) + "% hydrated)";
        } else {
            return "Good (" + String.format("%.2f", hydration) + "% hydrated)";
        }
    }
}

